
<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('js'); ?>
    <!-- INTERNAL INDEX JS -->
    
    
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="side-app">

        <!-- CONTAINER -->
        <div class="main-container container-fluid">

            <!-- PAGE-HEADER -->
            <div class="page-header">
                <h1 class="page-title">Dashboard</h1>
                <div>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
                    </ol>
                </div>
            </div>
            <!-- PAGE-HEADER END -->

            <!-- ROW-1 -->
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xl-12">
                    <div class="row">
                        <div class="col-lg-2 col-md-2 col-sm-12 col-xl-2">
                            <div class="card overflow-hidden">
                                <div class="card-body">
                                    <div class="d-flex">
                                        <div class="mt-2">
                                            <h6 class="">Total SPK</h6>
                                            <h2 class="mb-0 number-font"><?php echo e($cntSpk); ?></h2>
                                        </div>
                                        
                                    </div>
                                    <span class="text-muted fs-14">Rp. <?php echo number_format(filter_var($sumSpk, FILTER_SANITIZE_NUMBER_INT) ?:0,0,',','.'); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-2 col-md-2 col-sm-12 col-xl-2">
                            <div class="card overflow-hidden">
                                <div class="card-body">
                                    <div class="d-flex">
                                        <div class="mt-2">
                                            <h6 class="">Total PO</h6>
                                            <h2 class="mb-0 number-font"><?php echo e($cntPurchaseOrder); ?></h2>
                                        </div>
                                        
                                    </div>
                                    <span class="text-muted fs-14">Rp. <?php echo number_format(filter_var($sumPurchaseOrder, FILTER_SANITIZE_NUMBER_INT) ?:0,0,',','.'); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-2 col-md-2 col-sm-12 col-xl-2">
                            <div class="card overflow-hidden">
                                <div class="card-body">
                                    <div class="d-flex">
                                        <div class="mt-2">
                                            <h6 class="">Total DO</h6>
                                            <h2 class="mb-0 number-font"><?php echo e($cntDeliveryOrder); ?></h2>
                                        </div>
                                        
                                    </div>
                                    <span class="text-muted fs-14">Rp. <?php echo number_format(filter_var($sumDeliveryOrder, FILTER_SANITIZE_NUMBER_INT) ?:0,0,',','.'); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-2 col-md-2 col-sm-12 col-xl-2">
                            <div class="card overflow-hidden">
                                <div class="card-body">
                                    <div class="d-flex">
                                        <div class="mt-2">
                                            <h6 class="">Total BOQ</h6>
                                            <h2 class="mb-0 number-font"><?php echo e($cntBoq); ?></h2>
                                        </div>
                                        
                                    </div>
                                    <span class="text-muted fs-14">&nbsp;</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-2 col-md-2 col-sm-12 col-xl-2">
                            <div class="card overflow-hidden">
                                <div class="card-body">
                                    <div class="d-flex">
                                        <div class="mt-2">
                                            <h6 class="">Total SOS</h6>
                                            <h2 class="mb-0 number-font"><?php echo e($cntSos); ?></h2>
                                        </div>
                                        
                                    </div>
                                    
                                    <span class="text-muted fs-14">&nbsp;</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-2 col-md-2 col-sm-12 col-xl-2">
                            <div class="card overflow-hidden">
                                <div class="card-body">
                                    <div class="d-flex">
                                        <div class="mt-2">
                                            <h6 class="">Total Job Executor</h6>
                                            <h2 class="mb-0 number-font"><?php echo e($cntJobExecutor); ?></h2>
                                        </div>
                                        
                                    </div>
                                    
                                    <span class="text-muted fs-14">&nbsp;</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ROW-1 END -->

            <!-- ROW-2 -->
            <div class="row">
                <div class="col-6">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Total Project DO</h3>
                        </div>
                        <div class="card-body">
                            <div class="chart-container">
                                <canvas id="chartTotalProject" class="h-275"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-6">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Job Status</h3>
                        </div>
                        <div class="card-body">
                            <div class="chart-container">
                                <canvas id="chartStatusBoq" class="h-275"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ROW-2 END -->

            <!-- ROW-4 -->
            
            <!-- ROW-4 END -->
        </div>
        <!-- CONTAINER END -->
    </div>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('custom-js'); ?>
<script>
    $(function() {
	"use strict";

    var ctx = document.getElementById("chartTotalProject").getContext('2d');
    var myChart = new Chart(ctx, {
    type: 'horizontalBar',
    data: {
        labels: [
            <?php $__currentLoopData = $totalProject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                '<?php echo e($item->company_name?:"-"); ?>'
                <?php if(!($loop->last)): ?>
                    ,
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ],
        datasets: [{
        backgroundColor: [
            "#2ecc71",
            "#3498db",
            "#95a5a6"
        ],
        data: [
            <?php $__currentLoopData = $totalProject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($item->sum?:0); ?>

                <?php if(!($loop->last)): ?>
                    ,
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ]
        }]
    },
    options: {
        responsive: true,
        legend: {
            display: false
        },
        scales: {
           xAxes: [{
             ticks: {
                min: 0, // it is for ignoring negative step.
                beginAtZero: true,
               callback: function(value, index, values) {
                 return value.toLocaleString("id-ID",{style:"currency", currency:"IDR"});
               },
             }
           }]
        },
        onClick: function (e) {
            var activePointLabel = this.getElementsAtEvent(e)[0]._model.label;
            window.location.href = '/dashboard/detail-project/' + activePointLabel.replace(/[^A-Z0-9]/ig, '');
            // alert(activePointLabel.replace(/[^A-Z0-9]/ig, ''));
        },
        tooltips: {
            callbacks: {
                label: function (tooltipItem) {
                    return (new Intl.NumberFormat('id-ID', {
                        style: 'currency',
                        currency: 'IDR',
                    })).format(tooltipItem.xLabel);
                }
            }
        }
    }
    });

    var ctx = document.getElementById("chartStatusBoq").getContext('2d');
    var myChart = new Chart(ctx, {
    type: 'pie',
    data: {
        labels: [
            <?php $__currentLoopData = $jobStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                '<?php echo e($item->name?:"-"); ?>'
                <?php if(!($loop->last)): ?>
                    ,
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ],
        datasets: [{
        backgroundColor: [
            "#2ecc71",
            "#3498db",
            "#95a5a6",
            "#9b59b6",
            "#f1c40f",
            "#e74c3c",
            "#34495e"
        ],
        data: [
            <?php $__currentLoopData = $jobStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($item->count?:0); ?>

                <?php if(!($loop->last)): ?>
                    ,
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ]
        }]
    },
    options: {
            responsive: true,
            legend: {
                position: 'bottom',
                labels: {
                    boxWidth: 20,
                    padding: 20
                }
            },
            onClick: function (e) {
                var activePointLabel = this.getElementsAtEvent(e)[0]._model.label;
                window.location.href = '/dashboard/detail-progress/' + activePointLabel.replace(/[^a-z0-9\s]/gi, '');
            }
        }
    });
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Personal\PT. BKI\Project\bki-kso\code\resources\views/dashboard.blade.php ENDPATH**/ ?>