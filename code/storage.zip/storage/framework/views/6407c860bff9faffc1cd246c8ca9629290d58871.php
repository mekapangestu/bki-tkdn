<footer class="footer">
    <div class="container">
        <div class="row align-items-center flex-row-reverse">
            <div class="col-md-12 col-sm-12 text-center">
                Copyright © <span id="year"></span> <a href="javascript:void(0)">PT. Biro Klasifikasi Indonesia</a>. Development by <a href="javascript:void(0)"> PT. Tigasatu Cipta Solusi </a> All rights reserved.
            </div>
        </div>
    </div>
</footer>
<?php /**PATH D:\Project\Personal\PT. BKI\Project\bki-kso\code\resources\views/partials/footer.blade.php ENDPATH**/ ?>