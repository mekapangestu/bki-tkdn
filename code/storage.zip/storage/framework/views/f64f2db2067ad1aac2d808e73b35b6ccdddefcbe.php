
<?php $__env->startSection('title', 'Job Executor List'); ?>
<?php $__env->startSection('content'); ?>
    <div class="side-app">

        <!-- CONTAINER -->
        <div class="main-container container-fluid">

            <!-- PAGE-HEADER -->
            <div class="page-header">
                <h1 class="page-title"><?php echo $__env->yieldContent('title'); ?></h1>
                <div>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Job Executor</li>
                    </ol>
                </div>

            </div>
            <!-- PAGE-HEADER END -->

            <!-- Row -->
            <div class="row row-sm">
                <div class="col-lg-12">
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger" role="alert">
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-hidden="true">×</button>
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php elseif(session('success')): ?>
                        <div class="alert alert-success" role="alert">
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-hidden="true">×</button>
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Data List</h3>
                            <div class="card-options">
                                <div class="btn-group" style="margin-right: 8px">
                                    <a class="btn btn-primary" data-bs-target="#import" data-bs-toggle="modal">
                                        <li class="fa fa-plus"></li>
                                        Import
                                    </a>
                                    <a class="btn btn-primary" href="<?php echo e(route('je.export')); ?>">
                                        <li class="fa fa-plus"></li>
                                        Export
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="file-datatable" class="table table-bordered text-nowrap key-buttons border-bottom text-center">
                                    <thead>
                                        <tr>
                                            <th class="border-bottom-0" style="width: 5%">SOS No</th>
                                            <th class="border-bottom-0">Inspector</th>
                                            <th class="border-bottom-0">Tag Number</th>
                                            <th class="border-bottom-0">Equipment</th>
                                            <th class="border-bottom-0">Area</th>
                                            <th class="border-bottom-0">Location</th>
                                            <th class="border-bottom-0">Job Status</th>
                                            <th class="border-bottom-0" style="width: 25px">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($job->sos_no); ?></td>
                                                <td><?php echo e($job->inspector); ?></td>
                                                <td><?php echo e($job->tag_number); ?></td>
                                                <td><?php echo e($job->equipment); ?></td>
                                                <td><?php echo e($job->area); ?></td>
                                                <td><?php echo e($job->location); ?></td>
                                                <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($val->id == $job->job_status && $val->id == 7): ?>
                                                        <td><span class="badge rounded-pill bg-secondary text-white badge-lg me-2 mb-2 mt-2"><span onclick="generateQR(this)" style="cursor: pointer"><?php echo e($val->status); ?></span></span>
                                                        <span id="qr-image" class="qr-image" style="display: none"><?php echo QrCode::size(300)->generate(route('je.preview', $job->id)); ?></span>
                                                        <span id="qr-url" class="qr-url" style="display: none; padding-top: 30px"><a href="<?php echo e(route('je.preview', $job->id)); ?>">Click here to preview</a></span></td>
                                                    <?php elseif($val->id == $job->job_status): ?>
                                                        <td><span class="badge rounded-pill bg-secondary text-white badge-lg me-2 mb-2 mt-2"><?php echo e($val->status); ?></span></td>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                
                                                
                                                <td>
                                                    <div class="dropdown">
                                                        <button class="btn btn-light btn-sm dropdown-toggle" type="button" id="dropdownMenu" data-bs-toggle="dropdown" aria-expanded="false">
                                                            <span class="fe fe-more-horizontal fs-14"></span>
                                                        </button>

                                                        <ul class="dropdown-menu" aria-labelledby="dropdownMenu">
                                                            <li><a href="<?php echo e(route('job-executor.show', $job->id)); ?>" class="btn text-primary btn-sm" data-bs-toggle="tooltip" data-bs-original-title="View"><span class="fe fe-eye fs-14"></span> View</a></li>
                                                            <li><a href="<?php echo e(route('job-executor.edit', $job->id)); ?>" class="btn text-secondary btn-sm" data-bs-toggle="tooltip" data-bs-original-title="Edit"><span class="fe fe-edit fs-14"></span> Edit</a></li>
                                                            <li>
                                                                <form action="<?php echo e(route('job-executor.destroy', $job->id)); ?>" method="POST">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('DELETE'); ?>
                                                                    <button class="btn text-danger btn-sm bg-white" onclick="deleteFunction()"><span class="fe fe-trash fs-14" data-bs-toggle="tooltip" data-bs-original-title="Delete"></span> Delete</button>
                                                                </form>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Row -->
        </div>
        <!-- CONTAINER CLOSED -->

        <div class="modal fade" id="import">
            <div class="modal-dialog" role="document">
                <div class="modal-content modal-content-demo">
                    <div class="modal-header">
                        <h6 class="modal-title">Import</h6><button aria-label="Close" class="btn-close" data-bs-dismiss="modal"><span aria-hidden="true">&times;</span></button>
                    </div>
                    <div class="modal-body">
                        <form id="importJe" method="POST" enctype="multipart/form-data" action="<?php echo e(route('je.import')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="col-12">
                                <div class="form-group">
                                    <div class="form-group">
                                        <label for="file" class="form-label">Add File</label>
                                        <input class="form-control" type="file" autocomplete="off" name="file" required>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-primary" form="importJe">Submit</button> <button class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="qr-code">
            <div class="modal-dialog" role="document">
                <div class="modal-content modal-content-demo">
                    <div class="modal-header">
                        <h6 class="modal-title">Data Preview</h6><button aria-label="Close" class="btn-close" data-bs-dismiss="modal"><span aria-hidden="true">&times;</span></button>
                    </div>
                    <div class="modal-body text-center">
                        <span id="qr-image-modal"></span><br />
                        <span id="qr-url-modal"></span>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-js'); ?>
    <script>
        function generateQR(elem) {
            let qr = $(elem).parents('td').find('.qr-image').html()
            let url = $(elem).parents('td').find('.qr-url').html()

            // $("#temp").val($id);
            // $("#qr-image-modal").html($('#qr-image').html());
            // $("#qr-url-modal").html($('#qr-url').html());

            $("#qr-image-modal").html(qr);
            $("#qr-url-modal").html(url);


            $("#qr-code").modal('show');
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Personal\PT. BKI\Project\bki-kso\code\resources\views/admin/job-executor/index.blade.php ENDPATH**/ ?>