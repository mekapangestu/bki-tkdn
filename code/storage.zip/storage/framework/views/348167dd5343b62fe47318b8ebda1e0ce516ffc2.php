
<?php $__env->startSection('title', 'BOQ'); ?>
<?php $__env->startSection('content'); ?>
    <style>
        .datepicker {
            z-index: 10009 !important
        }
    </style>
    <div class="side-app">

        <!-- CONTAINER -->
        <div class="main-container container-fluid">

            <!-- PAGE-HEADER -->
            <div class="page-header">
                <h1 class="page-title"><?php echo $__env->yieldContent('title'); ?></h1>
                <div>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Data List</li>
                    </ol>
                </div>

            </div>
            <!-- PAGE-HEADER END -->

            <!-- Row -->
            <div class="row row-sm">
                <div class="col-lg-12">
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger" role="alert">
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-hidden="true">×</button>
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php elseif(session('success')): ?>
                        <div class="alert alert-success" role="alert">
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-hidden="true">×</button>
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Data List</h3>
                            <div class="card-options">
                                <div class="btn-group" style="margin-right: 8px">
                                    <a id="addDO" class="btn btn-primary disabled" data-bs-target="#modaldemo1" data-bs-toggle="modal">
                                        <li class="fa fa-plus"></li>
                                        Add DO
                                    </a>
                                    <a class="btn btn-primary" data-bs-target="#importBoq" data-bs-toggle="modal">
                                        <li class="fa fa-plus"></li>
                                        Import BOQ
                                    </a>
                                    <a class="btn btn-primary" href="<?php echo e(route('boq.export')); ?>">
                                        <li class="fa fa-plus"></li>
                                        Export BOQ
                                    </a>
                                </div>
                                
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="100-datatable" class="table table-bordered text-nowrap key-buttons border-bottom text-center">
                                    <thead>
                                        <tr>
                                            <th class="border-bottom-0" style="width: 5%">
                                                <input type="checkbox" id="checkAll">
                                            </th>
                                            <th class="border-bottom-0" style="width: 5%">PO No</th>
                                            <th class="border-bottom-0">Client Name</th>
                                            <th class="border-bottom-0">Area</th>
                                            <th class="border-bottom-0">Equipment</th>
                                            <th class="border-bottom-0">Tag No.</th>
                                            <th class="border-bottom-0">Type</th>
                                            <th class="border-bottom-0">Status</th>
                                            <th class="border-bottom-0" style="width: 25px">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <input type="checkbox" class="checkbox_check" name="boq_id[]" data-value="<?php echo e($val->contract_value); ?>" value="<?php echo e($val->id); ?>" form="do-form" <?php echo e($val->status_do ? 'disabled' : ($val->po_no == '-' ? 'disabled' : '')); ?>>
                                                </td>
                                                <td><?php echo e($val->po_no); ?></td>
                                                <td><?php echo e($val->company_name); ?></td>
                                                <td><?php echo e($val->area); ?></td>
                                                <td><?php echo e($val->equipment); ?></td>
                                                <td><?php echo e($val->tag_number); ?></td>
                                                <td><?php echo e($val->project_type != '-' && isset($val->typeName->name) ? $val->typeName->name : '-'); ?></td>
                                                <td class="text-center"><span class="badge rounded-pill <?php echo e($val->status_do ? 'bg-success' : 'bg-primary'); ?> text-white badge-sm me-1 mb-1 mt-1"><?php echo e($val->status_do ? 'DO Terbit' : 'DO Belum Terbit'); ?></span></td>
                                                <td>
                                                    <div class="dropdown">
                                                        <button class="btn btn-light btn-sm dropdown-toggle" type="button" id="dropdownMenu" data-bs-toggle="dropdown" aria-expanded="false">
                                                            <span class="fe fe-more-horizontal fs-14"></span>
                                                        </button>

                                                        <ul class="dropdown-menu" aria-labelledby="dropdownMenu">
                                                            <li><a href="<?php echo e(route('boq.show', $val->id)); ?>" class="btn text-primary btn-sm" data-bs-toggle="tooltip" data-bs-original-title="View"><span class="fe fe-eye fs-14"></span> View</a></li>
                                                            <li><a href="<?php echo e(route('boq.edit', $val->id)); ?>" class="btn text-secondary btn-sm" data-bs-toggle="tooltip" data-bs-original-title="Edit"><span class="fe fe-edit fs-14"></span> Edit</a></li>
                                                            <li>
                                                                <form action="<?php echo e(route('boq.destroy', $val->id)); ?>" method="POST">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('DELETE'); ?>
                                                                    <button class="btn text-danger btn-sm bg-white" onclick="deleteFunction()"><span class="fe fe-trash fs-14" data-bs-toggle="tooltip" data-bs-original-title="Delete"></span> Delete</button>
                                                                </form>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Row -->
        </div>
        <!-- CONTAINER CLOSED -->

    </div>
    <div class="modal fade" id="importBoq">
        <div class="modal-dialog" role="document">
            <div class="modal-content modal-content-demo">
                <div class="modal-header">
                    <h6 class="modal-title">Import BOQ</h6><button aria-label="Close" class="btn-close" data-bs-dismiss="modal"><span aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <form id="import-Boq" method="POST" enctype="multipart/form-data" action="<?php echo e(route('boq.import')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="col-12">
                            <div class="form-group">
                                <div class="form-group">
                                    <label for="file" class="form-label">Add File</label>
                                    <input class="form-control" type="file" autocomplete="off" name="file" required>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-primary" form="import-Boq">Submit</button> <a class="btn btn-light" data-bs-dismiss="modal">Cancel</a>
                </div>
            </div>
        </div>
    </div>
    <!-- BASIC MODAL -->
    <div class="modal fade" id="modaldemo1">
        <div class="modal-dialog" role="document">
            <div class="modal-content modal-content-demo">
                <div class="modal-header">
                    <h6 class="modal-title">Add DO</h6><button aria-label="Close" class="btn-close" data-bs-dismiss="modal"><span aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <form method="POST" id="do-form" class="from-prevent-multiple-submits" enctype="multipart/form-data" action="<?php echo e(route('do.store')); ?>">
                        <?php echo csrf_field(); ?>
                        
                        <div class="col-12">
                            <div class="form-group">
                                <label for="do_no" class="form-label">DO No</label>
                                <input type="text" class="form-control" name="do_no" placeholder="DO No" required>
                            </div>
                            <div class="form-group">
                                <label for="company_name" class="form-label">Company Name</label>
                                <input type="text" class="form-control" id="company_name" name="company_name" placeholder="Enter Company Name" required>
                            </div>
                            <div class="form-group">
                                <label for="project_value" class="form-label">Project Value</label>
                                <input type="text" class="form-control currency" id="project_value" name="project_value" placeholder="Enter Project Value" required>
                            </div>
                            <div class="form-group">
                                <div class="form-group">
                                    <label for="area" class="form-label">Upload DO</label>
                                    <input class="form-control" type="file" id="formFileMultiple" autocomplete="off" name="do" accept="application/pdf" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="do_date" class="form-label">DO Date</label>
                                <input type="text" class="form-control fc-datepicker" name="do_date" placeholder="Enter DO Date" required>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-primary from-prevent-multiple-submits" form="do-form">Submit</button> <a class="btn btn-light" data-bs-dismiss="modal">Cancel</a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom-js'); ?>
    <script>
        // let totalAllValue = 0
        // let totalAllBoq = []
        $(function() {
            $('#modaldemo1').on('shown.bs.modal', function(e) {
                let totalValue = 0
                $('input:checkbox.checkbox_check:checked').each(function() {
                    if (Number.isInteger($(this).data('value'))) {
                        totalValue += Number($(this).data('value'));
                    } else {
                        totalValue += Number($(this).data('value').replace(/[^0-9]/g, ''));
                    }
                });
                // totalValue = totalAllValue?totalAllValue:totalValue
                $('#project_value').val(totalValue).maskMoney('mask');
            })
        })
        $(document).on('change', 'input', function(e) {
            if ($('[name="boq_id[]"]:checked').length > 0) {
                $('#addDO').removeClass("disabled")
            } else {
                $('#addDO').addClass("disabled")
            }
            
            if ($('[name="boq_id[]"]').not(":disabled").length > $('[name="boq_id[]"]:checked').not(":disabled").length) {
                $('#checkAll').prop("checked", this.checked);
            } else {
                $('#checkAll').prop("checked", this.checked);
            }
        });

        $(document).on('change', '#checkAll', function() {
            $('td input[type="checkbox"]').not(":disabled").prop("checked", this.checked).change();
        });

        // let table = $('#100-datatable').DataTable({
        //     stateSave: true,
        //     language: {
        //         searchPlaceholder: 'Search...',
        //         scrollX: "100%",
        //         sSearch: '',
        //     },
        //     columnDefs: [
        //         { "orderable": false, "targets": [0] }
        //     ],
        //     lengthMenu: [[50, 100, 200, 500, -1], [50, 100, 200, "All"]],
        //     iDisplayLength: 100
        // });

        // $('#checkAll').change(function(){
        //     var rows,checked;  
        //     var rows = $("#100-datatable").DataTable().$('tr', {"filter": "applied"});// viewlist is
        //     checked = $(this).prop('checked');
        //     $.each(rows, function () {
        //         var checkbox = $($(this).find('td').eq(0)).find('input').not(":disabled").prop('checked', checked);
        //         if (checked) {
        //             totalAllValue += $($(this).find('td').eq(0)).find('input').not(":disabled").data('value') || 0
        //             totalAllBoq.push($($(this).find('td').eq(0)).find('input').not(":disabled").val());
        //         }else{
        //             totalAllValue = 0
        //             totalAllBoq = []
        //         }
        //     });
        //     $('#allboq').val(totalAllBoq)
        // });

        const checkboxes = document.querySelectorAll('td input[type="checkbox"]');
        let lastChecked;

        function handleCheck(e) {
            let inBetween = false;
            if (e.shiftKey && this.checked) {
                checkboxes.forEach(checkbox => {
                    if (checkbox === this || checkbox === lastChecked) {
                        inBetween = !inBetween;
                    }
                    if (inBetween) {
                        checkbox.checked = true;
                    }
                });
            }
            lastChecked = this;
        };

        checkboxes.forEach(checkbox => checkbox.addEventListener('click', handleCheck));
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Personal\PT. BKI\Project\bki-kso\code\resources\views/admin/boq/index.blade.php ENDPATH**/ ?>