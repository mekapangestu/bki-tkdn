<!doctype html>
<html lang="en" dir="ltr">

<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body class="app sidebar-mini ltr light-mode">

    

    <!-- PAGE -->
    <div class="page">
        <div class="page-main">

            <!-- app-Header -->
            <?php echo $__env->make('partials.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- /app-Header -->

            <!--APP-SIDEBAR-->
            <?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!--/APP-SIDEBAR-->

            <!--app-content open-->
            <div class="main-content app-content mt-0">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
            <!--app-content close-->

        </div>

        <!-- FOOTER -->
        <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- FOOTER END -->

    </div>

    <!-- BACK-TO-TOP -->
    <a href="#top" id="back-to-top"><i class="fa fa-angle-up"></i></a>

    <!-- JQUERY JS -->
    <script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>

    <!-- BOOTSTRAP JS -->
    <script src="<?php echo e(asset('assets/plugins/bootstrap/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/bootstrap/js/bootstrap.min.js')); ?>"></script>

    <!-- INPUT MASK JS-->
    <script src="<?php echo e(asset('assets/plugins/input-mask/jquery.mask.min.js')); ?>"></script>

    <!-- SPARKLINE JS-->
    <script src="<?php echo e(asset('assets/js/jquery.sparkline.min.js')); ?>"></script>

    <!-- SIDE-MENU JS-->
    <script src="<?php echo e(asset('assets/plugins/sidemenu/sidemenu.js')); ?>"></script>

    <!-- CHART-CIRCLE JS-->
    <script src="<?php echo e(asset('assets/js/circle-progress.min.js')); ?>"></script>

    <!-- PIETY CHART JS-->
    <script src="<?php echo e(asset('assets/plugins/peitychart/jquery.peity.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/peitychart/peitychart.init.js')); ?>"></script>

    <!-- FILE UPLOADES JS -->
    <script src="<?php echo e(asset('assets/plugins/fileuploads/js/fileupload.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/fileuploads/js/file-upload.js')); ?>"></script>

    <!-- INTERNAL File-Uploads Js-->
    <script src="<?php echo e(asset('assets/plugins/fancyuploder/jquery.ui.widget.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/fancyuploder/jquery.fileupload.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/fancyuploder/jquery.iframe-transport.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/fancyuploder/jquery.fancy-fileupload.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/fancyuploder/fancy-uploader.js')); ?>"></script>

    <!-- SIDEBAR JS -->
    <script src="<?php echo e(asset('assets/plugins/sidebar/sidebar.js')); ?>"></script>

    <!-- INTERNAL SELECT2 JS -->
    <script src="<?php echo e(asset('assets/plugins/select2/select2.full.min.js')); ?>"></script>

    <!-- INTERNAL Data tables js-->
    <script src="<?php echo e(asset('assets/plugins/datatable/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatable/js/dataTables.bootstrap5.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatable/dataTables.responsive.min.js')); ?>"></script>

    <!-- DATA TABLE JS-->
    <script src="<?php echo e(asset('assets/plugins/datatable/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatable/js/dataTables.bootstrap5.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatable/js/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatable/js/buttons.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatable/js/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatable/pdfmake/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatable/pdfmake/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatable/js/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatable/js/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatable/js/buttons.colVis.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatable/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatable/responsive.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/table-data.js')); ?>"></script>

    <!-- INTERNAL Bootstrap-Datepicker js-->
    <script src="<?php echo e(asset('assets/plugins/bootstrap-daterangepicker/daterangepicker.js')); ?>"></script>

    <!-- BOOTSTRAP-DATERANGEPICKER JS -->
    <script src="<?php echo e(asset('assets/plugins/bootstrap-daterangepicker/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/bootstrap-daterangepicker/daterangepicker.js')); ?>"></script>

    <!-- INTERNAL Bootstrap-Datepicker js-->
    <script src="<?php echo e(asset('assets/plugins/bootstrap-datepicker/bootstrap-datepicker.js')); ?>"></script>

    <!-- TIMEPICKER JS -->
    <script src="<?php echo e(asset('assets/plugins/time-picker/jquery.timepicker.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/time-picker/toggles.min.js')); ?>"></script>

    <!-- DATEPICKER JS -->
    <script src="<?php echo e(asset('assets/plugins/date-picker/date-picker.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/date-picker/jquery-ui.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/input-mask/jquery.maskedinput.js')); ?>"></script>

    <!-- INTERNAL CHARTJS CHART JS-->
    <script src="<?php echo e(asset('assets/plugins/chart/Chart.bundle.js')); ?>"></script>
    

    <!-- INTERNAL APEXCHART JS -->
    

    <!-- INTERNAL Flot JS -->
    

    <!-- INTERNAL Vector js -->
    


    <!-- FORMELEMENTS JS -->
    
    <script src="<?php echo e(asset('assets/js/form-elements.js')); ?>"></script>

    <!-- SWEET-ALERT JS -->
    <script src="<?php echo e(asset('assets/plugins/sweet-alert/sweetalert.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/sweet-alert.js')); ?>"></script>

    <!-- FORMVALIDATION JS -->
    <script src="<?php echo e(asset('assets/js/form-validation.js')); ?>"></script>

    <!-- Color Theme js -->
    <script src="<?php echo e(asset('assets/js/themeColors.js')); ?>"></script>

    <!-- Sticky js -->
    <script src="<?php echo e(asset('assets/js/sticky.js')); ?>"></script>

    <!-- CUSTOM JS -->
    <script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/js/jquery.maskMoney.min.js')); ?>"></script>

    <script type="text/javascript">
        Chart.defaults.global.defaultFontColor = "#000";
        function deleteFunction() {
            event.preventDefault(); // prevent form submit
            var form = event.target.form; // storing the form
            swal({
                title: "Are you sure?",
                text: "You won't be able to revert this!",
                type: "error",
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!',
                closeOnConfirm: false,
                closeOnCancel: false
            },
            function(isConfirm){
            if (isConfirm) {
                form.submit();
            } else {
                swal("Cancelled", "", "error");
            }
            });
        }
        $(function() {
            $('.from-prevent-multiple-submits').on('submit', function(){
                $('.from-prevent-multiple-submits').attr('disabled','true');
            })

            $(".currency").maskMoney({prefix: 'Rp. ', thousands:'.', precision: 0});
            $(".currency").maskMoney('mask');

            $(".numeric").on("input", function(event) {
                this.value = this.value.replace(/[^0-9]/g, "");
            });

            $(".valid").on("input", function(event) {
                this.value = this.value.replace(/[`!@#$%^&*_+\-=\[\]{};':"\\|<>\/?~]/g, "");
            });
        });
    </script>

    <?php echo $__env->yieldContent('js'); ?>
    <?php echo $__env->yieldContent('custom-js'); ?>
</body>

</html>
<?php /**PATH D:\Project\Personal\PT. BKI\Project\bki-kso\code\resources\views/layouts/app.blade.php ENDPATH**/ ?>