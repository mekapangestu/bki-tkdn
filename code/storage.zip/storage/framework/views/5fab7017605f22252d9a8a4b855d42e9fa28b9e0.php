<div class="sticky">
    <div class="app-sidebar__overlay" data-bs-toggle="sidebar"></div>
    <div class="app-sidebar">
        <div class="side-header">
            <a class="header-brand1" href="index.html">
                <img src="<?php echo e(asset('assets/images/bki-white-logo.png')); ?>" style="max-width: 80px;" class="header-brand-img desktop-logo" alt="logo">
                <img src="<?php echo e(asset('assets/images/bki-white-logo.png')); ?>" style="max-width: 50px;" class="header-brand-img toggle-logo" alt="logo">
                <img src="<?php echo e(asset('assets/images/bki-color-logo.png')); ?>" style="max-width: 50px;" class="header-brand-img light-logo" alt="logo">
                <img src="<?php echo e(asset('assets/images/bki-color-logo.png')); ?>" style="max-width: 80px;" class="header-brand-img light-logo1" alt="logo">
            </a>
            <!-- LOGO -->
        </div>
        <div class="main-sidemenu">
            <div class="slide-left disabled" id="slide-left"><svg xmlns="http://www.w3.org/2000/svg" fill="#7b8191" width="24" height="24" viewBox="0 0 24 24">
                    <path d="M13.293 6.293 7.586 12l5.707 5.707 1.414-1.414L10.414 12l4.293-4.293z" />
                </svg></div>
            <ul class="side-menu">
                <li class="sub-category">
                    <h3>Dashboard</h3>
                </li>
                <li class="slide">
                    <a class="side-menu__item has-link" data-bs-toggle="slide" href="<?php echo e(route('dashboard')); ?>"><i class="side-menu__icon fe fe-home"></i><span class="side-menu__label">Dashboard</span></a>
                </li>
                <li class="sub-category">
                    <h3>Main</h3>
                </li>
                <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'superadmin|marketing-admin')): ?>
                    <li>
                        <a class="side-menu__item has-link" href="<?php echo e(route('spk.index')); ?>"><i class="side-menu__icon fe fe-book"></i><span class="side-menu__label">SPK</span></a>
                    </li>
                    <li>
                        <a class="side-menu__item has-link" href="<?php echo e(route('po.index')); ?>"><i class="side-menu__icon fe fe-file-text"></i><span class="side-menu__label">SO/PO</span></a>
                    </li>
                    <li>
                        <a class="side-menu__item has-link" href="<?php echo e(route('boq.index')); ?>"><i class="side-menu__icon fe fe-clipboard"></i><span class="side-menu__label">Equipment/Installation</span></a>
                    </li>
                    <li>
                        <a class="side-menu__item has-link" href="<?php echo e(route('do.index')); ?>"><i class="side-menu__icon fe fe-truck"></i><span class="side-menu__label">Delivery Order</span></a>
                    </li>
                <?php endif; ?>
                <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'superadmin|operation-admin|marketing-admin')): ?>
                    <li>
                        <a class="side-menu__item has-link" href="<?php echo e(route('sos.index')); ?>"><i class="side-menu__icon fe fe-briefcase"></i><span class="side-menu__label">Branch Assignment</span></a>
                    </li>
                <?php endif; ?>
                <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'superadmin|operation-admin')): ?>
                    <li>
                        <a class="side-menu__item has-link" href="<?php echo e(route('job-executor.index')); ?>"><i class="side-menu__icon fe fe-briefcase"></i><span class="side-menu__label">Job Progress</span></a>
                    </li>
                <?php endif; ?>
                <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'superadmin')): ?>
                    <li class="sub-category">
                        <h3>Master Data</h3>
                    </li>
                    <li>
                        <a class="side-menu__item has-link" href="<?php echo e(route('user.index')); ?>"><i class="side-menu__icon fe fe-users"></i><span class="side-menu__label">User Mgt.</span></a>
                    </li>
                    <li>
                        <a class="side-menu__item has-link" href="<?php echo e(route('role.index')); ?>"><i class="side-menu__icon fe fe-user-check"></i><span class="side-menu__label">Role Mgt.</span></a>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="slide-right" id="slide-right"><svg xmlns="http://www.w3.org/2000/svg" fill="#7b8191" width="24" height="24" viewBox="0 0 24 24">
                    <path d="M10.707 17.707 16.414 12l-5.707-5.707-1.414 1.414L13.586 12l-4.293 4.293z" />
                </svg></div>
        </div>
    </div>
</div>
<?php /**PATH D:\Project\Personal\PT. BKI\Project\bki-kso\code\resources\views/partials/sidebar.blade.php ENDPATH**/ ?>