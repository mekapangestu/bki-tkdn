
<?php $__env->startSection('title', 'Edit BOQ'); ?>
<?php $__env->startSection('content'); ?>
    <div class="side-app">

        <!-- CONTAINER -->
        <div class="main-container container-fluid">

            <!-- PAGE-HEADER -->
            <div class="page-header">
                <h1 class="page-title"><?php echo $__env->yieldContent('title'); ?></h1>
                <div>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('boq.index')); ?>">Data List</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Edit</li>
                    </ol>
                </div>

            </div>
            <!-- PAGE-HEADER END -->

            <!-- Row -->
            <div class="row row-sm">
                <div class="col-lg-12">
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger" role="alert">
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-hidden="true">×</button>
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php elseif(session('success')): ?>
                        <div class="alert alert-success" role="alert">
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-hidden="true">×</button>
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Edit Data</h3>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="<?php echo e(route('boq.update', $boq->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="row">
                                    <div class="row peralatan">
                                        <div class="col-md-6 form-group">
                                            <label for="po_no" class="form-label">SPK Number</label>
                                            <input type="text" class="form-control" id="po_no" autocomplete="off" name="po_no" placeholder="Enter SO/PO Number" value="<?php echo e($po->spk_no); ?>" readonly>

                                        </div>
                                        <div class="col-md-6 form-group">
                                            <label for="po_no" class="form-label">SO/PO Number</label>
                                            <input type="text" class="form-control" id="po_no" autocomplete="off" name="po_no" placeholder="Enter SO/PO Number" value="<?php echo e($po->po_no); ?>" readonly>
                                            <input type="hidden" name="po_id" value="<?php echo e($po->id); ?>" readonly>

                                        </div>
                                        <div class="col-3">
                                            <div class="form-group">
                                                <label for="type" class="form-label">Type</label>
                                                <select class="form-control form-select select2" name="project_type">
                                                    <?php $__currentLoopData = $type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($val->id); ?>" <?php echo e($val->id == $boq->project_type ? 'selected' : ''); ?>><?php echo e($val->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <label for="inspection_date" class="form-label">Size</label>
                                                <input type="text" class="form-control" name="size" placeholder="Enter Size" value="<?php echo e($boq->size); ?>">
                                            </div>
                                        </div>
                                        <div class="col-3">
                                            <div class="form-group">
                                                <label for="tools" class="form-label">Equipment</label>
                                                <input type="text" class="form-control" id="equipment" name="equipment" placeholder="Enter Equipment" value="<?php echo e($boq->equipment); ?>">
                                            </div>
                                            <div class="form-group">
                                                <label for="inspection_date" class="form-label">Dimension</label>
                                                <input type="text" class="form-control" name="dimension" placeholder="Enter Dimension" value="<?php echo e($boq->dimension); ?>">
                                            </div>
                                        </div>
                                        <div class="col-3">
                                            <div class="form-group">
                                                <label for="tag_number" class="form-label">Tag No</label>
                                                <input type="text" class="form-control" id="tag_number" name="tag_number" placeholder="Enter Tag No" value="<?php echo e($boq->tag_number); ?>">
                                            </div>
                                            <div class="form-group">
                                                <label for="inspection_date" class="form-label">Capacity</label>
                                                <input type="text" class="form-control" name="capacity" placeholder="Enter Capacity" value="<?php echo e($boq->capacity); ?>">
                                            </div>
                                        </div>
                                        <div class="col-3">
                                            <div class="form-group">
                                                <label for="inspector" class="form-label">Value</label>
                                                <input type="text" class="form-control currency" id="contract_value" name="contract_value" placeholder="Enter Value" value="<?php echo e($boq->contract_value); ?>">
                                            </div>
                                            <div class="form-group">
                                                <label for="note" class="form-label">Note</label>
                                                <textarea class="form-control" id="note" name="note[]"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-primary mt-4 mb-0">Submit</button>
                            </form>
                        </div>
                    </div>
                    
                </div>
            </div>
            <!-- End Row -->
        </div>
        <!-- CONTAINER CLOSED -->

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Personal\PT. BKI\Project\bki-kso\code\resources\views/admin/boq/edit.blade.php ENDPATH**/ ?>