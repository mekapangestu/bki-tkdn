
<?php $__env->startSection('title', 'Edit Job Executor'); ?>
<?php $__env->startSection('content'); ?>
    <div class="side-app">

        <!-- CONTAINER -->
        <div class="main-container container-fluid">

            <!-- PAGE-HEADER -->
            <div class="page-header">
                <h1 class="page-title"><?php echo $__env->yieldContent('title'); ?></h1>
                <div>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('job-executor.index')); ?>">Data List</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Edit</li>
                    </ol>
                </div>

            </div>
            <!-- PAGE-HEADER END -->

            <!-- Row -->
            <div class="row row-sm">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Edit Data</h3>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="<?php echo e(route('job-executor.update', $result[0]->id)); ?>" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="row">
                                    <div class="col-6">
                                        <div class="form-group">
                                            <label for="sos_no" class="form-label">SOS Number</label>
                                            <input type="text" class="form-control" id="sos_no" autocomplete="off" name="sos_no" value="<?php echo e($result[0]->sos_no); ?>" placeholder="Enter SOS Number" readonly>
                                            <input type="hidden" class="form-control" id="job_status_hide" autocomplete="off" name="job_status_hide" value="<?php echo e($result[0]->job_status); ?>" placeholder="Enter Job Status">
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="form-group">
                                            <label for="type" class="form-label">Job Status</label>
                                            <select class="form-control" name="job_status">
                                                <option selected>Select Status</option>
                                                <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($val->id == $result[0]->job_status): ?>
                                                        <option value="<?php echo e($val->id); ?>" selected><?php echo e($val->status); ?></option>
                                                    <?php else: ?>
                                                        <option value="<?php echo e($val->id); ?>"><?php echo e($val->status); ?></option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <label for="SOS" class="form-label">
                                    <h5><b>Inspection Section</b></h5>
                                </label>
                                <div class="row">
                                    <div class="col-6">
                                        <div class="form-group">
                                            <label for="branch_name" class="form-label">Inspector</label>
                                            <input type="text" class="form-control" placeholder="Enter Inspector" id="inspector" autocomplete="off" name="inspector" value="<?php echo e($result[0]->inspector); ?>">
                                        </div>
                                        <div class="form-group">
                                            <label for="sos_date" class="form-label">Inspection Date </label>
                                            <input type="text" class="form-control fc-datepicker" id="inspection_date" autocomplete="off" name="inspection_date" placeholder="Enter Inspection Date" value="<?php echo e($result[0]->inspection_date); ?>">
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="form-group">
                                            <label for="" class="form-label">Job Document</label>
                                            <input class="form-control" type="file" id="formFileMultiple" autocomplete="off" name="job_doc" accept="application/pdf">
                                        </div>
                                        <div class="form-group">
                                            <label class="custom-control custom-checkbox-md">
                                                <?php if($result[0]->document_check == 1): ?>
                                                    <input type="checkbox" class="custom-control-input" name="document_check" value="1" checked>
                                                <?php else: ?>
                                                    <input type="checkbox" class="custom-control-input" name="document_check" value="1">
                                                <?php endif; ?>
                                                <span class="custom-control-label">Document Review</span>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                <label for="SOS" class="form-label">
                                    <h5><b>Minutes Section</b></h5>
                                </label>
                                <div class="row">
                                    <div class="col-6">
                                        <div class="form-group">
                                            <label for="branch_name" class="form-label">Minutes Number</label>
                                            <input type="text" class="form-control" placeholder="Enter Minutes Number" id="minutes_no" autocomplete="off" name="minutes_no" value="<?php echo e($result[0]->minutes_no); ?>">
                                        </div>
                                        <div class="form-group">
                                            <label for="minutes" class="form-label">Minutes Note</label>
                                            <textarea class="form-control" placeholder="Enter Minutes" id="minutes_note" autocomplete="off" name="minutes_note" style="height: 100px"><?php echo e($result[0]->minutes_note); ?></textarea>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="form-group">
                                            <label for="sos_date" class="form-label">Minutes Date </label>
                                            <input type="text" class="form-control fc-datepicker" id="minutes_date" autocomplete="off" name="minutes_date" placeholder="Enter Minutes Date" value="<?php echo e($result[0]->minutes_date); ?>">
                                        </div>
                                        <div class="form-group">
                                            <label for="" class="form-label">Minutes Document</label>
                                            <input class="form-control" type="file" id="formFileMultiple" autocomplete="off" name="minutes_doc" accept="application/pdf">
                                        </div>
                                    </div>
                                </div>
                                <label for="SOS" class="form-label">
                                    <h5><b>Certification Section</b></h5>
                                </label>
                                <div class="row">
                                    <div class="col-6">
                                        <div class="form-group">
                                            <label for="branch_name" class="form-label">COI Number</label>
                                            <input type="text" class="form-control" placeholder="Enter COI Number" id="coi_no" autocomplete="off" name="coi_no" value="<?php echo e($result[0]->coi_no); ?>">
                                        </div>
                                        <div class="form-group">
                                            <label for="sos_date" class="form-label">COI Date</label>
                                            <input type="text" class="form-control fc-datepicker" id="coi_date" autocomplete="off" name="coi_date" placeholder="Enter COI Date" value="<?php echo e($result[0]->coi_date); ?>">
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="form-group">
                                            <label for="sos_date" class="form-label">Expired Date </label>
                                            <input type="text" class="form-control fc-datepicker" id="expired_date" autocomplete="off" name="expired_date" placeholder="Enter Expired Date" value="<?php echo e($result[0]->expired_date); ?>">
                                        </div>
                                        <div class="form-group">
                                            <label for="" class="form-label">COI Certificate</label>
                                            <input class="form-control" type="file" id="formFileMultiple" autocomplete="off" name="coi_doc" accept="application/pdf">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-12">
                                        <div class="form-group">
                                            <label for="minutes" class="form-label">Notes</label>
                                            <textarea class="form-control" placeholder="Enter Notes" id="notes" autocomplete="off" name="notes" style="height: 100px"><?php echo e($result[0]->notes); ?></textarea>
                                        </div>
                                    </div>
                                </div>
                                <label for="RLA" class="form-label">
                                    <h5><b>RLA/Reengineering Section</b></h5>
                                </label>
                                <div class="row">
                                    <div class="col-6">
                                        <div class="form-group">
                                            <label for="" class="form-label">Upload SPK</label>
                                            <input class="form-control" type="file" id="formFileMultiple" autocomplete="off" name="minutes_doc" accept="application/pdf">
                                        </div>
                                        <div class="form-group">
                                            <label for="sos_date" class="form-label">PIC Company</label>
                                            <input type="text" class="form-control" id="pic_company" autocomplete="off" name="pic_company" placeholder="Enter PIC Company" value="<?php echo e($result[0]->pic_company); ?>">
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="form-group">
                                            <label for="" class="form-label">Upload BAST</label>
                                            <input class="form-control" type="file" id="formFileMultiple" autocomplete="off" name="minutes_doc" accept="application/pdf">
                                        </div>
                                    </div>
                                </div>
                                <br>
                                <button type="submit" class="btn btn-primary mt-4 mb-0">Submit</button>
                            </form>
                        </div>
                    </div>
                    <div class="card custom-card">
                        <div class="card-header border-bottom">
                            <h3 class="card-title">Uploaded Document</h3>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="example2" class="table table-bordered text-nowrap border-bottom text-center">
                                    <thead>
                                        <tr>
                                            <th class="border-bottom-0" style="width: 25px">No</th>
                                            <th class="border-bottom-0">File Name</th>
                                            <th class="border-bottom-0">Created At</th>
                                            <th class="border-bottom-0">Updated At</th>
                                            <th class="border-bottom-0" style="width: 50px">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $number = 1; ?>
                                        <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($number); ?></td>
                                                <td><?php echo e($file->name); ?></td>
                                                <td><?php echo e($file->created_at); ?></td>
                                                <td><?php echo e($file->updated_at); ?></td>
                                                <td>
                                                    <a href="<?php echo e(asset('storage/' . $file->path)); ?>" target="_blank" class="btn text-primary btn-sm" data-bs-toggle="tooltip" data-bs-original-title="View"><span class="fe fe-eye fs-14"></span></a>
                                                    <a href="<?php echo e(route('delete.file', [$result[0]->id, $file->label, $file->filename])); ?>" class="btn text-danger btn-sm" data-bs-toggle="tooltip" data-bs-original-title="Delete"><span class="fe fe-trash fs-14"></span></a>
                                                </td>
                                            </tr>
                                            <?php $number++; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Row -->
        </div>
        <!-- CONTAINER CLOSED -->

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom-js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Personal\PT. BKI\Project\bki-kso\code\resources\views/admin/job-executor/edit.blade.php ENDPATH**/ ?>