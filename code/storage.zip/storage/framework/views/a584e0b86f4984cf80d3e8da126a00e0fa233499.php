
<?php $__env->startSection('title', 'View DO'); ?>
<?php $__env->startSection('content'); ?>
    <style>
        .datepicker {
            z-index: 10009 !important
        }
    </style>
    <div class="side-app">

        <!-- CONTAINER -->
        <div class="main-container container-fluid">

            <!-- PAGE-HEADER -->
            <div class="page-header">
                <h1 class="page-title"><?php echo $__env->yieldContent('title'); ?></h1>
                <div>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('do.index')); ?>">Data List</a></li>
                        <li class="breadcrumb-item active" aria-current="page">View</li>
                    </ol>
                </div>

            </div>
            <!-- PAGE-HEADER END -->

            <!-- Row -->
            <div class="row row-sm">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">View Data</h3>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-3">
                                    <div class="form-group">
                                        <label for="do_no" class="form-label">DO Number</label>
                                        <input type="text" class="form-control" id="do_no" autocomplete="off" name="do_no" placeholder="Enter DO Number" value="<?php echo e($do->do_no); ?>" disabled>
                                    </div>
                                </div>
                                <div class="col-3">
                                    <div class="form-group">
                                        <label for="spk_no" class="form-label">Company Name</label>
                                        <input type="text" class="form-control" id="spk_no" autocomplete="off" name="spk_no" placeholder="Enter SPK Number" value="<?php echo e($do->company_name); ?>" disabled>
                                    </div>
                                </div>
                                <div class="col-3">
                                    <div class="form-group">
                                        <label for="project_balue" class="form-label">Project Value</label>
                                        <input type="text" class="form-control currency" id="project_value" autocomplete="off" name="project_value" placeholder="Enter Project Value" value="<?php echo e($do->project_value); ?>" disabled>
                                    </div>
                                </div>
                                <div class="col-3">
                                    <div class="form-group">
                                        <label for="description" class="form-label">DO Date</label>
                                        <input class="form-control" placeholder="Enter Description" id="description" autocomplete="off" name="description" value="<?php echo e($do->do_date); ?>" disabled>
                                    </div>
                                </div>
                            </div>
                            <br>
                            <a href="<?php echo e(route('do.index')); ?>" class="btn btn-primary mt-4 mb-0">Back</a>
                        </div>
                    </div>
                    <div class="card custom-card">
                        <div class="card-header border-bottom">
                            <h3 class="card-title">Uploaded Document</h3>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="example2" class="table table-bordered text-nowrap border-bottom text-center">
                                    <thead>
                                        <tr>
                                            <th class="border-bottom-0" style="width: 25px">No</th>
                                            <th class="border-bottom-0">File Name</th>
                                            <th class="border-bottom-0">Created At</th>
                                            <th class="border-bottom-0">Updated At</th>
                                            <th class="border-bottom-0" style="width: 50px">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $number = 1; ?>
                                        <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($number); ?></td>
                                                <td><?php echo e($file->name); ?></td>
                                                <td><?php echo e($file->created_at); ?></td>
                                                <td><?php echo e($file->updated_at); ?></td>
                                                <td>
                                                    <a href="<?php echo e(asset('storage/' . $file->path)); ?>" target="_blank" class="btn text-primary btn-sm" data-bs-toggle="tooltip" data-bs-original-title="View"><span class="fe fe-eye fs-14"></span></a>
                                                </td>
                                            </tr>
                                            <?php $number++; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="card custom-card">
                        <div class="card-header d-flex justify-content-between">
                            <h3 class="card-title">Data List</h3>
                            <div class="btn-group" style="margin-right: 8px">
                                <a id="addSOS" class="btn btn-primary disabled" data-bs-target="#sosModal" data-bs-toggle="modal">
                                    <li class="fa fa-plus"></li>
                                    Add SOS
                                </a>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="basic-datatable" class="table table-bordered text-nowrap key-buttons border-bottom text-center">
                                    <thead>
                                        <tr>
                                            <th class="border-bottom-0" style="width: 5%"><input type="checkbox" id="checkAll"></th>
                                            <th class="border-bottom-0">Type</th>
                                            <th class="border-bottom-0">Equipment</th>
                                            <th class="border-bottom-0">Tag No.</th>
                                            <th class="border-bottom-0">Value</th>
                                            <th class="border-bottom-0">SO/PO</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <input type="checkbox" class="checkbox_check" data-value="<?php echo e($val->contract_value); ?>" name="boq_id[]" value="<?php echo e($val->id); ?>" form="sos-form">
                                                </td>
                                                <td><?php echo e($val->typeName->name ?: '-'); ?></td>
                                                <td><?php echo e($val->equipment); ?></td>
                                                <td><?php echo e($val->tag_number); ?></td>
                                                <td>Rp. <?php echo number_format(filter_var($val->contract_value, FILTER_SANITIZE_NUMBER_INT) ?: 0,0,',','.'); ?></td>
                                                <td><?php echo e($val->po_no); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Row -->
        </div>
        <!-- CONTAINER CLOSED -->

    </div>
    <!-- BASIC MODAL -->
    <div class="modal fade" id="sosModal">
        <div class="modal-dialog" role="document">
            <div class="modal-content modal-content-demo">
                <div class="modal-header">
                    <h6 class="modal-title">Add SOS</h6><button aria-label="Close" class="btn-close" data-bs-dismiss="modal"><span aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <form id="sos-form" method="POST" action="<?php echo e(route('boqsos.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        
                        <div class="row">
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="sos_no" class="form-label">SOS No</label>
                                    <input type="text" class="form-control" id="sos_no" autocomplete="off" name="sos_no" placeholder="Enter SOS No" required>
                                </div>

                                <div class="form-group">
                                    <label for="sos_date" class="form-label">SOS Date</label>
                                    <input type="text" class="form-control fc-datepicker" id="sos_date" autocomplete="off" name="sos_date" placeholder="Enter SOS Date" required>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="value" class="form-label">Job Value</label>
                                    <input type="text" class="form-control currency" id="value" autocomplete="off" name="value" placeholder="Enter Job Value" required>
                                </div>
                                <div class="form-group">
                                    <label for="branch_name" class="form-label">Branch Name</label>
                                    <input type="text" class="form-control" placeholder="Enter Branch Name" id="description" autocomplete="off" name="branch_name" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="" class="form-label">Upload SOS</label>
                                <input class="form-control" type="file" id="formFileMultiple" autocomplete="off" name="sos" accept="application/pdf" required>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-primary" form="sos-form">Submit</button> <button class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom-js'); ?>
    <script>
        // let totalAllValue = 0
        // let totalAllBoq = []
        $('#sosModal').on('shown.bs.modal', function(e) {
            let totalValue = 0
            $('input:checkbox.checkbox_check:checked').each(function() {
                if (Number.isInteger($(this).data('value'))) {
                    totalValue += Number($(this).data('value'));
                } else {
                    totalValue += Number($(this).data('value').replace(/[^0-9]/g, ''));
                }
            });
            // totalValue = totalAllValue?totalAllValue:totalValue
            $('#value').val(totalValue).maskMoney('mask');
        })

        $(document).on('change', 'input', function(e) {
            if ($('[name="boq_id[]"]:checked').length > 0) {
                $('#addSOS').removeClass("disabled")
            } else {
                $('#addSOS').addClass("disabled")
            }

            if ($('[name="boq_id[]"]').not(":disabled").length > $('[name="boq_id[]"]:checked').not(":disabled").length) {
                $('#checkAll').prop("checked", this.checked);
            } else {
                $('#checkAll').prop("checked", this.checked);
            }
        });

        $(document).on('change', '#checkAll', function() {
            $('td input[type="checkbox"]').not(":disabled").prop("checked", this.checked).change();
        });

        // let table = $('#datatable').DataTable({
        //     stateSave: true,
        //     language: {
        //         searchPlaceholder: 'Search...',
        //         scrollX: "100%",
        //         sSearch: '',
        //     },
        //     columnDefs: [
        //         { "orderable": false, "targets": [0] }
        //     ]
        // });

        // $('#checkAll').change(function(){
        //     var rows,checked;  
        //     var rows = $("#datatable").DataTable().$('tr', {"filter": "applied"});// viewlist is
        //     checked = $(this).prop('checked');
        //     $.each(rows, function () {
        //         var checkbox = $($(this).find('td').eq(0)).find('input').not(":disabled").prop('checked', checked);
        //         if (checked) {
        //             totalAllValue += $($(this).find('td').eq(0)).find('input').not(":disabled").data('value') || 0
        //             totalAllBoq.push($($(this).find('td').eq(0)).find('input').not(":disabled").val());
        //         }else{
        //             totalAllValue = 0
        //             totalAllBoq = []
        //         }
        //     });
        //     $('#allboq').val(totalAllBoq)
        // });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Personal\PT. BKI\Project\bki-kso\code\resources\views/admin/do/view.blade.php ENDPATH**/ ?>