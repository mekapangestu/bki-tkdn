
<?php $__env->startSection('title', 'Add BOQ'); ?>
<?php $__env->startSection('js'); ?>
    <!-- BOOTSTRAP-DATERANGEPICKER JS -->
    <script src="/assets/plugins/bootstrap-daterangepicker/moment.min.js"></script>
    <script src="/assets/plugins/bootstrap-daterangepicker/daterangepicker.js"></script>

    <!-- TIMEPICKER JS -->
    <script src="/assets/plugins/time-picker/jquery.timepicker.js"></script>
    <script src="/assets/plugins/time-picker/toggles.min.js"></script>

    <!-- FORMELEMENTS JS -->
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <style>
        .peralatan .row {
            margin: 12px 0 !important;
            border: 1px solid #ccc;
        }

        .remove_field {
            margin: 12px;
        }
    </style>
    <div class="side-app">

        <!-- CONTAINER -->
        <div class="main-container container-fluid">

            <!-- PAGE-HEADER -->
            <div class="page-header">
                <h1 class="page-title"><?php echo $__env->yieldContent('title'); ?></h1>
                <div>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('boq.index')); ?>">Data List</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Add</li>
                    </ol>
                </div>

            </div>
            <!-- PAGE-HEADER END -->

            <!-- Row -->
            <div class="row row-sm">
                <div class="col-lg-12">
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger" role="alert">
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-hidden="true">×</button>
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php elseif(session('success')): ?>
                        <div class="alert alert-success" role="alert">
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-hidden="true">×</button>
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Form BOQ</h3>
                        </div>
                        <div class="card-body">
                            <form method="POST" enctype="multipart/form-data" action="<?php echo e(route('boq.store')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="row peralatan">
                                        <div class="col-md-6 form-group">
                                            
                                            <label for="po_no" class="form-label">SPK Number</label>
                                            <input type="text" class="form-control" id="spk_no" autocomplete="off" name="spk_no" placeholder="Enter SO/PO Number" value="<?php echo e($po->spk_no); ?>" readonly>

                                        </div>
                                        <div class="col-md-6 form-group">
                                            
                                            <label for="po_no" class="form-label">SO/PO Number</label>
                                            <input type="text" class="form-control" id="po_no" autocomplete="off" name="po_no" placeholder="Enter SO/PO Number" value="<?php echo e($po->po_no); ?>" readonly>
                                            <input type="hidden" name="po_id" value="<?php echo e($po->id); ?>" readonly>

                                        </div>
                                        
                                        <?php if (isset($component)) { $__componentOriginalcfd145099d1bf76fdfa297002719093d5c92bb26 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Boq\Peralatan::class, ['list' => $list,'po' => $po,'type' => $type]); ?>
<?php $component->withName('boq.peralatan'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcfd145099d1bf76fdfa297002719093d5c92bb26)): ?>
<?php $component = $__componentOriginalcfd145099d1bf76fdfa297002719093d5c92bb26; ?>
<?php unset($__componentOriginalcfd145099d1bf76fdfa297002719093d5c92bb26); ?>
<?php endif; ?>
                                    </div>
                                    <a class="add_field_button btn btn-info" style="width:100px;margin: 12px 0;">Add More</a>
                                </div>
                                <button type="submit" class="btn btn-primary mt-4 mb-0">Submit</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Row -->
        </div>
        <!-- CONTAINER CLOSED -->

    </div>
<?php $__env->startSection('custom-js'); ?>
    <script>
        $(document).ready(function() {
            var max_fields = 10; //maximum input boxes allowed
            var wrapper = $(".peralatan"); //Fields wrapper
            var add_button = $(".add_field_button"); //Add button ID

            var x = 1; //initlal text box count
            $(add_button).on("click", function(e) { //on add input button click
                e.preventDefault();
                if (x < max_fields) { //max input box allowed
                    x++; //text box increment
                    $(wrapper).append(`<div class="row" style="margin: 0;padding: 0;"><a href="#" class="btn btn-danger btn-sm remove_field" style="width:100px">Remove</a><div class="clearfix"></div><?php if (isset($component)) { $__componentOriginalcfd145099d1bf76fdfa297002719093d5c92bb26 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Boq\Peralatan::class, ['list' => $list,'po' => $po,'type' => $type]); ?>
<?php $component->withName('boq.peralatan'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcfd145099d1bf76fdfa297002719093d5c92bb26)): ?>
<?php $component = $__componentOriginalcfd145099d1bf76fdfa297002719093d5c92bb26; ?>
<?php unset($__componentOriginalcfd145099d1bf76fdfa297002719093d5c92bb26); ?>
<?php endif; ?></div>`); //add input box
                }
                // $('.fc-datepicker').datepicker({
                //     dateFormat: 'yy-mm-dd'
                // });
                $(".currency").maskMoney({
                    prefix: 'Rp. ',
                    thousands: '.',
                    precision: 0
                });
            });

            $(wrapper).on("click", ".remove_field", function(e) { //user click on remove text
                e.preventDefault();
                $(this).parent('div').remove();
                x--;
            })
        });

        // $(function(e) {
        //     $('.fc-datepicker').datepicker({
        //         dateFormat: 'yy-mm-dd'
        //     });
        // });
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Personal\PT. BKI\Project\bki-kso\code\resources\views/admin/boq/create.blade.php ENDPATH**/ ?>