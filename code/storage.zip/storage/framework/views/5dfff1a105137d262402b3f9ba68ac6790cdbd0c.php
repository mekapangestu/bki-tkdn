
<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('js'); ?>
    <!-- INTERNAL INDEX JS -->
    
    
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="side-app">

        <!-- CONTAINER -->
        <div class="main-container container-fluid">

            <!-- PAGE-HEADER -->
            <div class="page-header">
                <h1 class="page-title">Dashboard</h1>
                <div>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Detail Project</li>
                    </ol>
                </div>
            </div>
            <!-- PAGE-HEADER END -->

            <!-- ROW-2 -->
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Detail Project <?php echo e($companyName); ?></h3>
                        </div>
                        <div class="card-body">
                            <div class="chart-container">
                                <canvas id="chartDetailProject"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ROW-2 END -->
        </div>
        <!-- CONTAINER END -->
    </div>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('custom-js'); ?>
<script>
    $(function() {
	"use strict";

    var ctx = document.getElementById("chartDetailProject").getContext('2d');
    var myChart = new Chart(ctx, {
    type: 'horizontalBar',
    data: {
        labels: [
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                '<?php echo e($item->branch_name?:"-"); ?>'
                <?php if(!($loop->last)): ?>
                    ,
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ],
        datasets: [{
        data: [
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($item->value?:0); ?>

                <?php if(!($loop->last)): ?>
                    ,
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ]
        }]
    },
    options: {
        responsive: true,
        legend: {
            display: false
        },
        scales: {
           xAxes: [{
             ticks: {
                min: 0, // it is for ignoring negative step.
                beginAtZero: true,
               callback: function(value, index, values) {
                 return value.toLocaleString("id-ID",{style:"currency", currency:"IDR"});
               },
               fontSize: 25,
            }
           }],
           yAxes: [{
                ticks: {
                    fontSize: 25,
                },
                // barThickness: 50
            }]
        },
        tooltips: {
            callbacks: {
                label: function (tooltipItem) {
                    return (new Intl.NumberFormat('id-ID', {
                        style: 'currency',
                        currency: 'IDR',
                    })).format(tooltipItem.xLabel);
                }
            }
        }
    }
    });
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Personal\PT. BKI\Project\bki-kso\code\resources\views/detail-project.blade.php ENDPATH**/ ?>