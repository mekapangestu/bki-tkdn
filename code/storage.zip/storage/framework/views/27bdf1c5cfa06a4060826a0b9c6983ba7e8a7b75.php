
<?php $__env->startSection('title', 'Preview Data'); ?>
<?php $__env->startSection('content'); ?>
    <!-- PAGE -->
    <div class="page">
        <div class="">


            <!-- CONTAINER -->
            <div class="container-login" style="width: 50%; margin: 0 auto;">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Job Detail Preview</h3>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="branch_name" class="form-label">COI Number</label>
                                    <input type="text" class="form-control" placeholder="Enter COI Number" id="coi_no" autocomplete="off" name="coi_no" value="<?php echo e($data[0]->coi_no); ?>" disabled>
                                </div>
                                <div class="form-group">
                                    <label for="branch_name" class="form-label">Type</label>
                                    <input type="text" class="form-control" placeholder="Enter COI Number" id="coi_no" autocomplete="off" name="coi_no" value="<?php echo e($data[0]->type_name); ?>" disabled>
                                </div>
                                <div class="form-group">
                                    <label for="branch_name" class="form-label">Equipment</label>
                                    <input type="text" class="form-control" placeholder="Enter COI Number" id="coi_no" autocomplete="off" name="coi_no" value="<?php echo e($data[0]->equipment); ?>" disabled>
                                </div>
                                <div class="form-group">
                                    <label for="branch_name" class="form-label">COI Date</label>
                                    <input type="text" class="form-control" placeholder="Enter COI Number" id="coi_no" autocomplete="off" name="coi_no" value="<?php echo e($data[0]->coi_date); ?>" disabled>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="sos_no" class="form-label">Company Name</label>
                                    <input type="text" class="form-control" id="sos_no" autocomplete="off" name="sos_no" value="<?php echo e($data[0]->company_name); ?>" placeholder="Enter Company Name" disabled>
                                </div>
                                <div class="form-group">
                                    <label for="branch_name" class="form-label">Tag Number</label>
                                    <input type="text" class="form-control" placeholder="Enter COI Number" id="coi_no" autocomplete="off" name="coi_no" value="<?php echo e($data[0]->tag_number); ?>" disabled>
                                </div>
                                <div class="form-group">
                                    <label for="branch_name" class="form-label">Inspection Date</label>
                                    <input type="text" class="form-control" placeholder="Enter COI Number" id="coi_no" autocomplete="off" name="coi_no" value="<?php echo e($data[0]->inspection_date); ?>" disabled>
                                </div>
                                <div class="form-group">
                                    <label for="branch_name" class="form-label">Expired Date</label>
                                    <input type="text" class="form-control" placeholder="Enter COI Number" id="coi_no" autocomplete="off" name="coi_no" value="<?php echo e($data[0]->expired_date); ?>" disabled>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12">
                                <div class="form-group">
                                    <label for="branch_name" class="form-label">Certificate</label>
                                    <span><a href="<?php echo e(Storage::url($coi[0]->path)); ?>">Click to preview certificate</a></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- CONTAINER CLOSED -->

        </div>
    </div>
    <!-- End PAGE -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Personal\PT. BKI\Project\bki-kso\code\resources\views/preview.blade.php ENDPATH**/ ?>