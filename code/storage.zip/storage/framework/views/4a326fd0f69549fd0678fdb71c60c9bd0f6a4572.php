
<?php $__env->startSection('title', 'SPK'); ?>
<?php $__env->startSection('content'); ?>
    <div class="side-app">

        <!-- CONTAINER -->
        <div class="main-container container-fluid">

            <!-- PAGE-HEADER -->
            <div class="page-header">
                <h1 class="page-title"><?php echo $__env->yieldContent('title'); ?></h1>
                <div>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">SPK</li>
                    </ol>
                </div>

            </div>
            <!-- PAGE-HEADER END -->

            <!-- Row -->
            <div class="row row-sm">
                <div class="col-lg-12">
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger" role="alert">
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-hidden="true">×</button>
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php elseif(session('success')): ?>
                        <div class="alert alert-success" role="alert">
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-hidden="true">×</button>
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Data List</h3>
                            <div class="card-options">
                                <div class="btn-group">
                                    <a class="btn btn-primary" href="<?php echo e(route('spk.create')); ?>">
                                        <li class="fa fa-plus"></li>
                                        Add
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="file-datatable" class="table table-bordered key-buttons border-bottom text-center">
                                    <thead>
                                        <tr>
                                            <th class="border-bottom-0">SPK No</th>
                                            <th class="border-bottom-0">Project Name</th>
                                            <th class="border-bottom-0">Client Name</th>
                                            <th class="border-bottom-0">Project Value</th>
                                            <th class="border-bottom-0">Area</th>
                                            <th class="border-bottom-0">Location</th>
                                            <th class="border-bottom-0">Status</th>
                                            <th class="border-bottom-0" style="width: 50px">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($spk->spk_no); ?></td>
                                                <td><?php echo e($spk->project_name); ?></td>
                                                <td><?php echo e($spk->company_name); ?></td>
                                                <td>Rp. <?php echo number_format(filter_var($spk->project_value, FILTER_SANITIZE_NUMBER_INT) ?: 0,0,',','.'); ?></td>
                                                <td><?php echo e($spk->area); ?></td>
                                                <td><?php echo e($spk->location); ?></td>
                                                <?php if($spk->po_no != null && $spk->status == 'Valid'): ?>
                                                    <td class="text-center"><span class="badge rounded-pill bg-success text-white badge-sm me-1 mb-1 mt-1"><?php echo e($spk->status); ?> & PO Release</span></td>
                                                <?php elseif($spk->po_no != null && $spk->status == 'Expired'): ?>
                                                    <td class="text-center"><span class="badge rounded-pill bg-danger text-white badge-sm me-1 mb-1 mt-1"><?php echo e($spk->status); ?> & PO Release</span></td>
                                                <?php elseif($spk->status == 'Valid'): ?>
                                                    <td class="text-center"><span class="badge rounded-pill bg-success text-white badge-sm me-1 mb-1 mt-1"><?php echo e($spk->status); ?></span></td>
                                                <?php else: ?>
                                                    <td class="text-center"><span class="badge rounded-pill bg-danger text-white badge-sm me-1 mb-1 mt-1"><?php echo e($spk->status); ?></span></td>
                                                <?php endif; ?>
                                                <td>
                                                    <div class="dropdown">
                                                        <button class="btn btn-light btn-sm dropdown-toggle" type="button" id="dropdownMenu" data-bs-toggle="dropdown" aria-expanded="false">
                                                            <span class="fe fe-more-horizontal fs-14"></span>
                                                        </button>

                                                        <ul class="dropdown-menu" aria-labelledby="dropdownMenu">
                                                            <li><a href="<?php echo e(route('spk.po', $spk->id)); ?>" class="btn text-warning btn-sm" data-bs-toggle="tooltip" data-bs-original-title="Create PO"><span class="fe fe-file-plus fs-14"></span> Create PO</a></li>
                                                            <li><a href="<?php echo e(route('spk.show', $spk->id)); ?>" class="btn text-primary btn-sm" data-bs-toggle="tooltip" data-bs-original-title="View"><span class="fe fe-eye fs-14"></span> View</a></li>
                                                            <li><a href="<?php echo e(route('spk.edit', $spk->id)); ?>" class="btn text-secondary btn-sm" data-bs-toggle="tooltip" data-bs-original-title="Edit"><span class="fe fe-edit fs-14"></span> Edit</a></li>
                                                            <li>
                                                                <form action="<?php echo e(route('spk.destroy', $spk->id)); ?>" method="POST">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('DELETE'); ?>
                                                                    <button class="btn text-danger btn-sm bg-white" onclick="deleteFunction()"><span class="fe fe-trash fs-14" data-bs-toggle="tooltip" data-bs-original-title="Delete"></span> Delete</button>
                                                                </form>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Row -->
        </div>
        <!-- CONTAINER CLOSED -->

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Personal\PT. BKI\Project\bki-kso\code\resources\views/admin/spk/index.blade.php ENDPATH**/ ?>