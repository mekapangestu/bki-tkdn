
<?php $__env->startSection('title', 'View BOQ'); ?>
<?php $__env->startSection('content'); ?>
    <div class="side-app">

        <!-- CONTAINER -->
        <div class="main-container container-fluid">

            <!-- PAGE-HEADER -->
            <div class="page-header">
                <h1 class="page-title"><?php echo $__env->yieldContent('title'); ?></h1>
                <div>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('boq.index')); ?>">Data List</a></li>
                        <li class="breadcrumb-item active" aria-current="page">View</li>
                    </ol>
                </div>

            </div>
            <!-- PAGE-HEADER END -->

            <!-- Row -->
            <div class="row row-sm">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">View Data</h3>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="row peralatan">
                                    <div class="col-md-6 form-group">
                                        <label for="po_no" class="form-label">SPK Number</label>
                                        <input type="text" class="form-control" id="spk_no" autocomplete="off" name="spk_no" placeholder="Enter SO/PO Number" value="<?php echo e($po->spk_no); ?>" readonly>

                                    </div>
                                    <div class="col-md-6 form-group">
                                        <label for="po_no" class="form-label">SO/PO Number</label>
                                        <input type="text" class="form-control" id="po_no" autocomplete="off" name="po_no" placeholder="Enter SO/PO Number" value="<?php echo e($po->po_no); ?>" readonly>
                                    </div>
                                    <div class="col-3">
                                        <div class="form-group">
                                            <label for="type" class="form-label">Type</label>
                                            <?php $__currentLoopData = $type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($boq->project_type == $val->id): ?>
                                                    <input type="text" class="form-control" id="project_type" autocomplete="off" name="project_type" placeholder="Enter SO/PO Number" value="<?php echo e($val->name); ?>" disabled>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                        </div>
                                        <div class="form-group">
                                            <label for="inspection_date" class="form-label">Size</label>
                                            <input type="text" class="form-control" name="size" placeholder="Enter Size" value="<?php echo e($boq->size); ?>" disabled>
                                        </div>
                                    </div>
                                    <div class="col-3">
                                        <div class="form-group">
                                            <label for="tools" class="form-label">Equipment</label>
                                            <input type="text" class="form-control" id="equipment" name="equipment" placeholder="Enter Equipment" value="<?php echo e($boq->equipment); ?>" disabled>
                                        </div>
                                        <div class="form-group">
                                            <label for="inspection_date" class="form-label">Dimension</label>
                                            <input type="text" class="form-control" name="dimension" placeholder="Enter Dimension" value="<?php echo e($boq->dimension); ?>" disabled>
                                        </div>
                                    </div>
                                    <div class="col-3">
                                        <div class="form-group">
                                            <label for="tag_number" class="form-label">Tag No</label>
                                            <input type="text" class="form-control" id="tag_number" name="tag_number" placeholder="Enter Tag No" value="<?php echo e($boq->tag_number); ?>" disabled>
                                        </div>
                                        <div class="form-group">
                                            <label for="inspection_date" class="form-label">Capacity</label>
                                            <input type="text" class="form-control" name="capacity" placeholder="Enter Capacity" value="<?php echo e($boq->capacity); ?>" disabled>
                                        </div>
                                    </div>
                                    <div class="col-3">
                                        <div class="form-group">
                                            <label for="inspector" class="form-label">Value</label>
                                            <input type="text" class="form-control currency" id="contract_value" name="contract_value" placeholder="Enter Value" value="<?php echo e($boq->contract_value); ?>" disabled>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <a href="<?php echo e(route('boq.index')); ?>" class="btn btn-primary mt-4 mb-0">Back</a>
                        </div>
                    </div>
                    <div class="card custom-card">
                        <div class="card-header border-bottom">
                            <h3 class="card-title">Uploaded Document</h3>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="example2" class="table table-bordered text-nowrap border-bottom text-center">
                                    <thead>
                                        <tr>
                                            <th class="border-bottom-0" style="width: 25px">No</th>
                                            <th class="border-bottom-0">File Name</th>
                                            <th class="border-bottom-0">Created At</th>
                                            <th class="border-bottom-0">Updated At</th>
                                            <th class="border-bottom-0" style="width: 50px">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $number = 1; ?>
                                        <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($number); ?></td>
                                                <td><?php echo e($file->name); ?></td>
                                                <td><?php echo e($file->created_at); ?></td>
                                                <td><?php echo e($file->updated_at); ?></td>
                                                <td>
                                                    <a href="<?php echo e(asset('storage/' . $file->path)); ?>" target="_blank" class="btn text-primary btn-sm" data-bs-toggle="tooltip" data-bs-original-title="View"><span class="fe fe-eye fs-14"></span></a>
                                                </td>
                                            </tr>
                                            <?php $number++; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Row -->
        </div>
        <!-- CONTAINER CLOSED -->

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Personal\PT. BKI\Project\bki-kso\code\resources\views/admin/boq/view.blade.php ENDPATH**/ ?>