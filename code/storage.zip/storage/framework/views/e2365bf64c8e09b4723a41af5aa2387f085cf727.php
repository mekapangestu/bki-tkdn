
<?php $__env->startSection('title', 'Add SPK'); ?>
<?php $__env->startSection('content'); ?>
    <div class="side-app">

        <!-- CONTAINER -->
        <div class="main-container container-fluid">

            <!-- PAGE-HEADER -->
            <div class="page-header">
                <h1 class="page-title"><?php echo $__env->yieldContent('title'); ?></h1>
                <div>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('spk.index')); ?>">Data List</a></li>
                        <li class="breadcrumb-item active" aria-current="page"><?php echo $__env->yieldContent('title'); ?></li>
                    </ol>
                </div>

            </div>
            <!-- PAGE-HEADER END -->

            <!-- Row -->
            <div class="row row-sm">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title"><?php echo $__env->yieldContent('title'); ?></h3>
                        </div>
                        <div class="card-body">
                            <?php if($errors->any()): ?>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="alert alert-danger"><?php echo e($error); ?></div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            <form method="POST" action="<?php echo e(route('spk.store')); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-3">
                                        <div class="form-group">
                                            <label for="spk_no" class="form-label">SPK Number</label>
                                            <input type="text" class="form-control" id="spk_no" autocomplete="off" name="spk_no" placeholder="Enter SPK Number" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="project_balue" class="form-label">Project Value</label>
                                            <input type="text" class="form-control currency" id="project_balue" autocomplete="off" name="project_value" placeholder="Enter Project Value" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="description" class="form-label">Description</label>
                                            <textarea class="form-control" placeholder="Enter Description" id="description" autocomplete="off" name="description" style="height: 100px"></textarea>
                                        </div>
                                    </div>
                                    <div class="col-3">
                                        <div class="form-group">
                                            <label for="project_name" class="form-label">Project Name</label>
                                            <input type="text" class="form-control" id="project_name" autocomplete="off" name="project_name" placeholder="Enter Project Name" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="company_name" class="form-label">Client Name</label>
                                            <input type="text" class="form-control" id="company_name" autocomplete="off" name="company_name" placeholder="Enter Client Name" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="description" class="form-label">Scope of Work</label>
                                            <textarea class="form-control" placeholder="Enter Scope of Work" id="sow" autocomplete="off" name="sow" style="height: 100px"></textarea>
                                        </div>
                                    </div>
                                    <div class="col-3">
                                        <div class="form-group">
                                            <label for="location" class="form-label">Location</label>
                                            <input type="text" class="form-control" id="location" autocomplete="off" name="location" placeholder="Enter Location" required>
                                        </div>
                                        <label class="form-label">Start Date</label>
                                        <div class="input-group">
                                            <div class="input-group-text">
                                                <i class="fa fa-calendar text-white"></i>
                                            </div>
                                            <input class="form-control" id="datepicker-start" autocomplete="off" placeholder="Enter Start Date" type="text" name="start_date" required>
                                        </div>
                                    </div>
                                    <div class="col-3">
                                        <div class="form-group">
                                            <label for="area" class="form-label">Area</label>
                                            <input type="text" class="form-control" id="area" autocomplete="off" name="area" placeholder="Enter Area" required>
                                        </div>
                                        <label class="form-label">End Date</label>
                                        <div class="input-group">
                                            <div class="input-group-text">
                                                <i class="fa fa-calendar text-white"></i>
                                            </div>
                                            <input class="form-control" id="datepicker-end" autocomplete="off" placeholder="Enter End Date" type="text" name="end_date" required>
                                        </div>
                                    </div>
                                </div>
                                <br>
                                <div class="row">
                                    <div class="col-12">
                                        <div class="form-group">
                                            <h3 class="card-title">Uploaded Document</h3>
                                            <label for="" class="form-label">SPK</label>
                                            <input class="form-control" type="file" id="formFileMultiple" autocomplete="off" name="spk" accept="application/pdf" required>
                                        </div>
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-primary mt-4 mb-0">Submit</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Row -->
        </div>
        <!-- CONTAINER CLOSED -->

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Personal\PT. BKI\Project\bki-kso\code\resources\views/admin/spk/create.blade.php ENDPATH**/ ?>