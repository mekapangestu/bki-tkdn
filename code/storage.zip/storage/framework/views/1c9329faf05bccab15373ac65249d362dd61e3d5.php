
<?php $__env->startSection('title', 'View SOS'); ?>
<?php $__env->startSection('content'); ?>
    <style>
        .datepicker {
            z-index: 10009 !important
        }
    </style>
    <div class="side-app">

        <!-- CONTAINER -->
        <div class="main-container container-fluid">

            <!-- PAGE-HEADER -->
            <div class="page-header">
                <h1 class="page-title"><?php echo $__env->yieldContent('title'); ?></h1>
                <div>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('sos.index')); ?>">Data List</a></li>
                        <li class="breadcrumb-item active" aria-current="page">View</li>
                    </ol>
                </div>

            </div>
            <!-- PAGE-HEADER END -->

            <!-- Row -->
            <div class="row row-sm">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">View Data</h3>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-3">
                                    <div class="form-group">
                                        <label for="sos_no" class="form-label">SOS Number</label>
                                        <input type="text" class="form-control" id="sos_no" autocomplete="off" name="sos_no" placeholder="Enter SOS Number" value="<?php echo e($sos->sos_no); ?>" disabled>
                                    </div>
                                </div>
                                <div class="col-3">
                                    <div class="form-group">
                                        <label for="spk_no" class="form-label">Branch Name</label>
                                        <input type="text" class="form-control" id="spk_no" autocomplete="off" name="spk_no" placeholder="Enter SPK Number" value="<?php echo e($sos->branch_name); ?>" disabled>
                                    </div>
                                </div>
                                <div class="col-3">
                                    <div class="form-group">
                                        <label for="project_balue" class="form-label">Project Value</label>
                                        <input type="text" class="form-control currency" id="project_value" autocomplete="off" name="project_value" placeholder="Enter Project Value" value="<?php echo e($sos->value); ?>" disabled>
                                    </div>
                                </div>
                                <div class="col-3">
                                    <div class="form-group">
                                        <label for="description" class="form-label">SOS Date</label>
                                        <input class="form-control" placeholder="Enter Description" id="description" autocomplete="off" name="description" disabled value="<?php echo e($sos->sos_date); ?>">
                                    </div>
                                </div>
                            </div>
                            <a href="<?php echo e(route('sos.index')); ?>" class="btn btn-primary mt-4 mb-0">Back</a>
                        </div>
                        <br>
                    </div>
                </div>
                <div class="card custom-card">
                    <div class="card-header border-bottom">
                        <h3 class="card-title">Uploaded Document</h3>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="example2" class="table table-bordered text-nowrap border-bottom text-center">
                                <thead>
                                    <tr>
                                        <th class="border-bottom-0" style="width: 25px">No</th>
                                        <th class="border-bottom-0">File Name</th>
                                        <th class="border-bottom-0">Created At</th>
                                        <th class="border-bottom-0">Updated At</th>
                                        <th class="border-bottom-0" style="width: 50px">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $number = 1; ?>
                                    <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($number); ?></td>
                                            <td><?php echo e($file->name); ?></td>
                                            <td><?php echo e($file->created_at); ?></td>
                                            <td><?php echo e($file->updated_at); ?></td>
                                            <td>
                                                <a href="<?php echo e(asset('storage/' . $file->path)); ?>" target="_blank" class="btn text-primary btn-sm" data-bs-toggle="tooltip" data-bs-original-title="View"><span class="fe fe-eye fs-14"></span></a>
                                            </td>
                                        </tr>
                                        <?php $number++; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'superadmin|operation-admin')): ?>
                    <div class="card custom-card">
                        <div class="card-header d-flex justify-content-between">
                            <h3 class="card-title">Data List</h3>
                            <div class="btn-group" style="margin-right: 8px">
                                <a id="addExecutor" class="btn btn-primary disabled" data-bs-target="#sosModal" data-bs-toggle="modal">
                                    <li class="fa fa-plus"></li>
                                    Add Job Executor
                                </a>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="basic-datatable" class="table table-bordered text-nowrap key-buttons border-bottom text-center">
                                    <thead>
                                        <tr>
                                            <th class="border-bottom-0" style="width: 5%"><input type="checkbox" id="checkAll"></th>
                                            <th class="border-bottom-0">Type</th>
                                            <th class="border-bottom-0">Equipment</th>
                                            <th class="border-bottom-0">Tag No.</th>
                                            <th class="border-bottom-0">Value</th>
                                            <th class="border-bottom-0">SO/PO</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <input type="checkbox" class="checkbox_check" name="boq_id[]" value="<?php echo e($val->id); ?>" form="sos-form">
                                                </td>
                                                <td><?php echo e($val->typeName->name?:'-'); ?></td>
                                                <td><?php echo e($val->equipment); ?></td>
                                                <td><?php echo e($val->tag_number); ?></td>
                                                <td>Rp. <?php echo number_format(filter_var($val->contract_value, FILTER_SANITIZE_NUMBER_INT) ?:0,0,',','.'); ?></td>
                                                <td><?php echo e($val->po_no); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <!-- End Row -->
    </div>
    <!-- CONTAINER CLOSED -->

    </div>
    <!-- BASIC MODAL -->
    <div class="modal fade" id="sosModal">
        <div class="modal-dialog" role="document">
            <div class="modal-content modal-content-demo">
                <div class="modal-header">
                    <h6 class="modal-title">Add Job Executor</h6><button aria-label="Close" class="btn-close" data-bs-dismiss="modal"><span aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <form id="sos-form" method="POST" action="<?php echo e(route('job-executor.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        
                        <div class="row">
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="sos_no" class="form-label">SOS Number</label>
                                    <input type="text" class="form-control" id="sos_no" autocomplete="off" name="sos_no" value="<?php echo e($sos->sos_no); ?>" placeholder="Enter SOS Number" readonly>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="type" class="form-label">Job Status</label>
                                    <select class="form-control" name="job_status">
                                        <option selected disabled>Select Status</option>
                                        <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($val->id); ?>"><?php echo e($val->status); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <label for="SOS" class="form-label">
                            <h5><b>Inspection Section</b></h5>
                        </label>
                        <div class="row">
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="branch_name" class="form-label">Inspector</label>
                                    <input type="text" class="form-control" placeholder="Enter Inspector" id="inspector" autocomplete="off" name="inspector">
                                </div>
                                <div class="form-group">
                                    <label for="sos_date" class="form-label">Inspection Date </label>
                                    <input type="text" class="form-control fc-datepicker" id="inspection_date" autocomplete="off" name="inspection_date" placeholder="Enter Inspection Date">
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="" class="form-label">Job Document</label>
                                    <input class="form-control" type="file" id="formFileMultiple" autocomplete="off" name="job" accept="application/pdf">
                                </div>
                                <div class="form-group">
                                    <label class="custom-control custom-checkbox-md">
                                        <input type="checkbox" class="custom-control-input" name="document_check" value="1">
                                        <span class="custom-control-label">Document Review</span>
                                    </label>
                                </div>
                            </div>
                        </div>
                        <label for="SOS" class="form-label">
                            <h5><b>Minutes Section</b></h5>
                        </label>
                        <div class="row">
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="branch_name" class="form-label">Minutes Number</label>
                                    <input type="text" class="form-control" placeholder="Enter Minutes Number" id="minutes_no" autocomplete="off" name="minutes_no">
                                </div>
                                <div class="form-group">
                                    <label for="minutes" class="form-label">Minutes Note</label>
                                    <textarea class="form-control" placeholder="Enter Minutes" id="minutes_note" autocomplete="off" name="minutes_note" style="height: 100px"></textarea>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="sos_date" class="form-label">Minutes Date </label>
                                    <input type="text" class="form-control fc-datepicker" id="minutes_date" autocomplete="off" name="minutes_date" placeholder="Enter Minutes Date">
                                </div>
                                <div class="form-group">
                                    <label for="" class="form-label">Minutes Document</label>
                                    <input class="form-control" type="file" id="formFileMultiple" autocomplete="off" name="minutes" accept="application/pdf">
                                </div>
                            </div>
                        </div>
                        <label for="SOS" class="form-label">
                            <h5><b>Certification Section</b></h5>
                        </label>
                        <div class="row">
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="branch_name" class="form-label">COI Number</label>
                                    <input type="text" class="form-control" placeholder="Enter COI Number" id="coi_no" autocomplete="off" name="coi_no">
                                </div>
                                <div class="form-group">
                                    <label for="sos_date" class="form-label">COI Date</label>
                                    <input type="text" class="form-control fc-datepicker" id="coi_date" autocomplete="off" name="coi_date" placeholder="Enter COI Date">
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="sos_date" class="form-label">Expired Date </label>
                                    <input type="text" class="form-control fc-datepicker" id="expired_date" autocomplete="off" name="expired_date" placeholder="Enter Expired Date">
                                </div>
                                <div class="form-group">
                                    <label for="" class="form-label">COI Certificate</label>
                                    <input class="form-control" type="file" id="formFileMultiple" autocomplete="off" name="coi" accept="application/pdf">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12">
                                <div class="form-group">
                                    <label for="minutes" class="form-label">Notes</label>
                                    <textarea class="form-control" placeholder="Enter Notes" id="notes" autocomplete="off" name="notes" style="height: 100px"></textarea>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-primary" form="sos-form">Submit</button> <button class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom-js'); ?>
    <script>
        // let totalAllBoq = []
        $(document).on('change', 'input', function(e) {
            if ($('[name="boq_id[]"]:checked').length > 0) {
                $('#addExecutor').removeClass("disabled")
            } else {
                $('#addExecutor').addClass("disabled")
            }

            if ($('[name="boq_id[]"]').not(":disabled").length > $('[name="boq_id[]"]:checked').not(":disabled").length) {
                $('#checkAll').prop("checked", this.checked);
            } else {
                $('#checkAll').prop("checked", this.checked);
            }
        });

        $(document).on('change', '#checkAll', function() {
            $('td input[type="checkbox"]').not(":disabled").prop("checked", this.checked).change();
        });

        // let table = $('#datatable').DataTable({
        //     stateSave: true,
        //     language: {
        //         searchPlaceholder: 'Search...',
        //         scrollX: "100%",
        //         sSearch: '',
        //     },
        //     columnDefs: [
        //         { "orderable": false, "targets": [0] }
        //     ]
        // });

        // $('#checkAll').change(function(){
        //     var rows,checked;  
        //     var rows = $("#datatable").DataTable().$('tr', {"filter": "applied"});// viewlist is
        //     checked = $(this).prop('checked');
        //     $.each(rows, function () {
        //         var checkbox = $($(this).find('td').eq(0)).find('input').not(":disabled").prop('checked', checked);
        //         if (checked) {
        //             totalAllBoq.push($($(this).find('td').eq(0)).find('input').not(":disabled").val());
        //         }else{
        //             totalAllBoq = []
        //         }
        //     });
        //     $('#allboq').val(totalAllBoq)
        // });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Personal\PT. BKI\Project\bki-kso\code\resources\views/admin/sos/view.blade.php ENDPATH**/ ?>