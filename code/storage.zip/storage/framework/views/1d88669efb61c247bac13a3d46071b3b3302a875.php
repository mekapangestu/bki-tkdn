<div class="col-3">
    
    <div class="form-group">
        <label for="type" class="form-label">Type</label>
        <select class="form-control form-select select2" name="project_type[]">
            <?php $__currentLoopData = $type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($val->id); ?>"><?php echo e($val->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="form-group">
        <label for="inspection_date" class="form-label">Size</label>
        <input type="text" class="form-control" name="size[]" placeholder="Enter Size">
    </div>
</div>
<div class="col-3">
    <div class="form-group">
        <label for="tools" class="form-label">Equipment</label>
        <input type="text" class="form-control" id="tools" name="equipment[]" placeholder="Enter Equipment">
    </div>

    <div class="form-group">
        <label for="inspection_date" class="form-label">Dimension</label>
        <input type="text" class="form-control" name="dimension[]" placeholder="Enter Dimension">
    </div>

    
</div>
<div class="col-3">
    <div class="form-group">
        <label for="tag_number" class="form-label">Tag No</label>
        <input type="text" class="form-control" id="tag_number" name="tag_number[]" placeholder="Enter Tag No">
    </div>
    <div class="form-group">
        <label for="inspection_date" class="form-label">Capacity</label>
        <input type="text" class="form-control" name="capacity[]" placeholder="Enter Capacity">
    </div>
</div>
<div class="col-3">
    <div class="form-group">
        <label for="inspector" class="form-label">Value</label>
        <input type="text" class="form-control currency" id="contract_value" name="contract_value[]" placeholder="Enter Value">
    </div>
    <div class="form-group">
        <label for="note" class="form-label">Note</label>
        <textarea class="form-control" id="note" name="note[]"></textarea>
    </div>
</div><?php /**PATH D:\Project\Personal\PT. BKI\Project\bki-kso\code\resources\views/components/boq/peralatan.blade.php ENDPATH**/ ?>